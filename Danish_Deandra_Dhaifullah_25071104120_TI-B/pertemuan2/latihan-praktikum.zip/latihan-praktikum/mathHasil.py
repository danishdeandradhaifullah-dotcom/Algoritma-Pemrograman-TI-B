import myMath as mm

tambah = mm.penambahan(12, 5)
kurang = mm.pengurangan(13,10)
perkalian = mm.perkalian(17,15)
pembagianNol = mm.pembagian(67,0)
pembagian = mm.pembagian(15,3)
modulus = mm.modulus(15,4)
fibonacci = mm.fibonacci(8)

print(tambah)
print(kurang)
print(perkalian)
print(pembagianNol)
print(pembagian)
print(modulus)
print(fibonacci)
